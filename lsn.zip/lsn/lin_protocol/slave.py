import serial
import termios
import time
import RPi.GPIO as GPIO
from .constants import *
from .exceptions import *

def open_lin_serial(port: str, baudrate: int = 19200) -> serial.Serial:
    ser = serial.Serial(
        port=port,
        baudrate=baudrate,
        bytesize=serial.EIGHTBITS,
        parity=serial.PARITY_NONE,
        stopbits=serial.STOPBITS_ONE,
        timeout=0
    )
    fd = ser.fileno()
    attrs = termios.tcgetattr(fd)
    attrs[0] |= termios.PARMRK | termios.INPCK
    attrs[0] &= ~termios.IGNPAR
    termios.tcsetattr(fd, termios.TCSANOW, attrs)
    return ser

class LINSlave:
    def __init__(self, serial_port=DEFAULT_SERIAL_PORT, baud_rate=DEFAULT_BAUD_RATE,
                 wakeup_pin=DEFAULT_WAKEUP_PIN):
        self.ser = open_lin_serial(serial_port, baud_rate)
        self.baud_rate = baud_rate
        self.wakeup_pin = wakeup_pin
        self.frame_handlers = {}
        
        GPIO.setmode(GPIO.BCM)
        GPIO.setup(self.wakeup_pin, GPIO.IN, pull_up_down=GPIO.PUD_UP)
    
    def register_frame_handler(self, frame_id, handler, data_length=None):
        """
        Register handler for specific frame ID

        Args:
            frame_id:    LIN frame ID to handle
            handler:     Function that takes (data) and returns response data
            data_length: Expected number of data bytes when master sends data
                         on this frame (command frames only).
                         Leave None for request frames where master sends
                         only the header and slave responds.
        """
        self.frame_handlers[frame_id] = (handler, data_length)

    def process_frames(self):
        """
        Main processing loop - waits for and handles incoming frames
        """
        try:
            while True:
                try:
                    frame_id, pid_byte, data = self._receive_header()
                except LINError:
                    continue

                if frame_id in self.frame_handlers:
                    handler, _ = self.frame_handlers[frame_id]
                    response = handler(data)
                    if response is not None:
                        self._send_response(pid_byte, response)

        except KeyboardInterrupt:
            return
    
    BREAK_MARKER = b'\xff\x00\x00'   # Real BREAK with PARMRK enabled
    SYNC_BYTE = 0x55
    WBP_FRAME_ID = 0x12
    WBP_RESPONSE_BYTES = 5           # 4 data + 1 checksum

    def _receive_header(self):
      buf = bytearray()

      while True:
          # Fill buffer with available bytes
          if self.ser.in_waiting:
              buf += self.ser.read(self.ser.in_waiting)
  
          # Look for real BREAK marker (3-byte sequence from PARMRK)
          idx = buf.find(self.BREAK_MARKER)
          if idx == -1:
              time.sleep(0.001)
              continue
  
          # Discard everything before the BREAK
          buf = buf[idx + 3:]
  
          # Wait for SYNC byte
          buf = self._fill_buf(buf, needed=1, timeout_ms=35)
          if not buf:
              continue
  
          sync = buf[0]
          buf = buf[1:]
  
          if sync != self.SYNC_BYTE:
              continue  # Not a valid header, keep scanning
  
          # Wait for PID byte
          buf = self._fill_buf(buf, needed=1)
          if not buf:
              continue
  
          pid_byte = buf[0]
          buf = buf[1:]
  
          frame_id = self.parse_pid(pid_byte)
          if frame_id is None:
              buf.clear()
              continue
  
          # If this is WBP frame — absorb response bytes and loop back
          if frame_id == self.WBP_FRAME_ID:
              self._drain_bytes(self.WBP_RESPONSE_BYTES)
              buf.clear()
              continue
  
          return frame_id, pid_byte, None
    
    def _send_response(self, pid, data):
        """Send response data with checksum"""
        if len(data) > MAX_FRAME_DATA_LENGTH:
            raise ValueError("Data too long for LIN frame")

        checksum = self.calculate_checksum(pid, data)
        self.ser.write(data)
        self.ser.write(bytes([checksum]))
        self.ser.flush()
    
    @staticmethod
    def parse_pid(pid_byte):
        """Extract frame ID and verify parity"""
        frame_id = pid_byte & 0x3F
        p0 = (pid_byte >> 6) & 0x01
        p1 = (pid_byte >> 7) & 0x01
        
        calc_p0 = (frame_id ^ (frame_id >> 1) ^ (frame_id >> 2) ^ (frame_id >> 4)) & 0x01
        calc_p1 = ~((frame_id >> 1) ^ (frame_id >> 3) ^ (frame_id >> 4) ^ (frame_id >> 5)) & 0x01
        
        if p0 != calc_p0 or p1 != calc_p1:
            return None
        return frame_id
    
    @staticmethod
    def calculate_checksum(pid, data):
        """Calculate checksum for response"""
        checksum = pid
        for byte in data:
            checksum += byte
            if checksum > 0xFF:
                checksum -= 0xFF
        return (0xFF - checksum) & 0xFF
    
    @staticmethod
    def verify_checksum(pid, data, received_checksum):
        """Verify checksum of received data"""
        calculated = LINSlave.calculate_checksum(pid, data)
        return calculated == received_checksum
        
    def _fill_buf(self, buf: bytearray, needed: int, timeout_ms: int = 20) -> bytearray:
        deadline = time.monotonic() + timeout_ms / 1000
        while len(buf) < needed:
            if time.monotonic() > deadline:
                return bytearray()
            if self.ser.in_waiting:
                buf += self.ser.read(self.ser.in_waiting)
            else:
                time.sleep(0.0005)
        return buf

    def _drain_bytes(self, count: int, timeout_ms: int = 15):
        deadline = time.monotonic() + timeout_ms / 1000
        received = 0
        while received < count and time.monotonic() < deadline:
            if self.ser.in_waiting:
                n = min(self.ser.in_waiting, count - received)
                self.ser.read(n)
                received += n
            else:
                time.sleep(0.0005)
            
    def close(self):
        self.ser.close()
        GPIO.cleanup()